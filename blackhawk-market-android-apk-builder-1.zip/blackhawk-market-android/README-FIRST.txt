BLACKHAWK MARKET — ANDROID APK BUILD PACKAGE

This package wraps the existing Blackhawk Market website in an Android app using Capacitor and includes a GitHub Actions workflow to build an installable debug APK in the cloud.

WHAT'S INCLUDED
- www/index.html: Blackhawk Market shopping website
- package.json: Capacitor dependencies
- capacitor.config.json: Android app name and package ID
- .github/workflows/build-apk.yml: cloud APK build workflow

IMPORTANT
- This creates a test/debug APK. It is not a Play Store release.
- The shop currently uses sample products/prices and a demo checkout. No real orders or M-Pesa payments are connected.
- Do not collect real customer information until a secure backend, privacy notice, order handling, and payment integration are added.

BUILD FROM AN ANDROID PHONE USING GITHUB
1. Download and extract this ZIP.
2. In a browser, sign in to GitHub and create a new repository named blackhawk-market-android. A public repo is easiest for first-time setup; do not upload secrets or private customer data.
3. Upload all files and folders from this package to the repository root. Make sure the hidden .github/workflows/build-apk.yml file is included. If the GitHub mobile uploader hides dot-folders or makes this difficult, use GitHub's web upload in desktop mode or a computer.
4. Commit the files to the main branch.
5. Open the repository's Actions tab. Select "Build Blackhawk Market APK", tap "Run workflow", and run it on main. A push to main should also start it automatically.
6. Wait for the workflow to finish successfully.
7. Open that successful workflow run, scroll to Artifacts, and download "blackhawk-market-debug-apk". Extract the downloaded artifact ZIP to get app-debug.apk.
8. Tap app-debug.apk on your phone to install. If Android blocks it, allow your browser/files app to install unknown apps for this install, then retry. Only install APKs you built and trust.

IF THE WORKFLOW FAILS
Open the failed run and copy or screenshot the first red error section. The workflow generates the native Android project during the cloud build, so the android/ folder is not expected in the original upload.

OFFICIAL REFERENCES
Capacitor Android setup: https://capacitorjs.com/docs/android
GitHub Actions artifacts: https://docs.github.com/actions/using-workflows/storing-workflow-data-as-artifacts
